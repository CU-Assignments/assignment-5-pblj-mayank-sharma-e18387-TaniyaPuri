import java.util.ArrayList;
import java.util.Scanner;

public class SumOfIntegers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Prompt user to enter numbers separated by spaces
        System.out.print("Enter numbers separated by spaces: ");
        String input = scanner.nextLine();
        
        // Split the input string into individual numbers
        String[] numbers = input.split(" ");
        
        // Create an ArrayList to store Integer objects
        ArrayList<Integer> integers = new ArrayList<>();
        
        // Convert each string into an Integer using autoboxing
        for (String number : numbers) {
            integers.add(Integer.parseInt(number));  // Autoboxing
        }
        
        // Calculate the sum using unboxing
        int sum = 0;
        for (Integer integer : integers) {
            sum += integer;  // Unboxing
        }
        
        // Display the result
        System.out.println("Sum of numbers: " + sum);
        
        scanner.close();
    }
}

